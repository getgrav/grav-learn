# Reviews Plugin

This is a sample plugin project for working with Flex Objects.  It's not intended as a 'release-ready' plugin, but more of a working example to follow along with.

### Manual Installation

To install the plugin manually, download the zip-version of this repository and unzip it under `/your/site/grav/user/plugins`. Then rename the folder to `reviews`. You can find these files on [GitHub](https://github.com/trilbymedia/grav-plugin-reviews) or via [GetGrav.org](https://getgrav.org/downloads/plugins).

You should now have all the plugin files under

    /your/site/grav/user/plugins/reviews

> NOTE: This plugin is requires the `flex-objects` plugin to be installed.

