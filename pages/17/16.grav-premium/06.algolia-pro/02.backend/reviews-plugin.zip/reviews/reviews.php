<?php
namespace Grav\Plugin;

use Composer\Autoload\ClassLoader;
use Grav\Common\Data\Data;
use Grav\Common\Plugin;
use Grav\Common\Utils;
use Grav\Events\FlexRegisterEvent;
use Grav\Events\PermissionsRegisterEvent;
use Grav\Framework\Acl\PermissionsReader;
use Grav\Framework\Flex\FlexDirectory;
use Grav\Plugin\AlgoliaSearch\FlexReviewsSearch;
use Grav\Plugin\Reviews\ReviewObject;
use Grav\Plugin\Sitemap\SitemapEntry;
use RocketTheme\Toolbox\Event\Event;
use Twig\TwigFilter;

/**
 * Class ReviewsPlugin
 * @package Grav\Plugin
 */
class ReviewsPlugin extends Plugin
{
    protected $review;

    /** @var int[] */
    public $features = [
        'blueprints' => 100,
    ];

    /**
     * @return array
     *
     * The getSubscribedEvents() gives the core a list of events
     *     that the plugin wants to listen to. The key of each
     *     array section is the event that the plugin listens to
     *     and the value (in the form of an array) contains the
     *     callable (or function) as well as the priority. The
     *     higher the number the higher the priority.
     */
    public static function getSubscribedEvents(): array
    {
        return [
            FlexRegisterEvent::class => [
                ['onRegisterFlex', 100]
            ],
            PermissionsRegisterEvent::class => [
                ['onRegisterPermissions', 100]
            ],
            'onPluginsInitialized' => [
                ['onPluginsInitialized', 0]
            ]
        ];
    }

    /**
     * Composer autoload
     *
     * @return ClassLoader
     */
    public function autoload(): ClassLoader
    {
        return require __DIR__ . '/vendor/autoload.php';
    }

    /**
     * Initialize the plugin
     */
    public function onPluginsInitialized()
    {
        $this->enable([
            'onTwigTemplatePaths'        => ['onTwigTemplatePaths', 0],
            'onAssetsInitialized'        => ['onAssetsInitialized', 0],
            'onSitemapProcessed'         => ['onSitemapProcessed', 0],
            'onAlgoliaProRegisterSearch' => ['onAlgoliaProRegisterSearch', 0]
        ]);
    }

    public function onRegisterFlex(FlexRegisterEvent $event): void
    {
        $flex = $event->flex;
        $flex->addDirectoryType('reviews', 'blueprints://flex/reviews.yaml');
    }

    /**
     * Initial stab at registering permissions (WIP)
     *
     * @param PermissionsRegisterEvent $event
     * @return void
     */
    public function onRegisterPermissions(PermissionsRegisterEvent $event): void
    {
        $permissions = $event->permissions;
        $actions = PermissionsReader::fromYaml("plugin://{$this->name}/permissions.yaml");
        $permissions->addActions($actions);
    }

    public function onTwigTemplatePaths()
    {
        $this->grav['twig']->twig_paths[] = __DIR__ . '/templates';
    }

    public function onAssetsInitialized()
    {
        $this->grav['assets']->addCss("plugin://{$this->name}/assets/reviews.css");
    }

    public function onSitemapProcessed(Event $e)
    {
        $sitemap = $e['sitemap'];
        $directory = $this->grav['flex']->getDirectory('reviews');
        foreach ($directory->getCollection()->filterBy(['published' => true]) as $review) {
            $route = "reviews/id:{$review->review_route}";
            $entry = new SitemapEntry(
                Utils::url($route, true),
                date('Y-m-d', $review->getTimestamp()),
                'daily',
                '1.0'
            );
            $sitemap[Utils::url($route)] = $entry;
        }
        $e['sitemap'] = $sitemap;
    }

    public function onAlgoliaProRegisterSearch(Event $e): void
    {
        /** @var Data $register */
        $register = $e['register'];
        $register->merge([
            'flex-reviews-search' => 'Flex Reviews Search',
        ]);
    }

}
