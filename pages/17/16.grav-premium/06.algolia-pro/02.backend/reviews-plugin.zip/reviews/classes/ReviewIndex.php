<?php

namespace Grav\Plugin\Reviews;

use Grav\Common\File\CompiledYamlFile;
use Grav\Common\Flex\Types\Generic\GenericIndex;
use Grav\Common\Grav;
use Grav\Framework\Flex\Interfaces\FlexStorageInterface;

class ReviewIndex extends GenericIndex
{
    public const VERSION = parent::VERSION . '.1';

    /**
     * @param array $meta
     * @param array $data
     * @param FlexStorageInterface $storage
     */
    public static function updateObjectMeta(array &$meta, array $data, FlexStorageInterface $storage)
    {
        $key = (string)($data['review_route'] ?? $meta['key'] ?? $meta['storage_key']);
        $meta['key'] = $storage->normalizeKey($key);
    }

    /**
     * @param FlexStorageInterface $storage
     * @return array
     */
    public static function loadEntriesFromStorage(FlexStorageInterface $storage): array
    {
        // Load saved index.
        $index = static::loadIndex($storage);

        $version = $index['version'] ?? 0;
        $timestamp = $index['timestamp'] ?? 0;
        $force = static::VERSION !== $version;
        if (!$force && $timestamp && $timestamp > time() - 2) {
            return $index['index'];
        }

        // Load up to date index.
        $entries = parent::loadEntriesFromStorage($storage);

        return static::updateIndexFile($storage, $index['index'], $entries, ['force_update' => $force]);
    }

    /**
     * @param FlexStorageInterface $storage
     * @return CompiledYamlFile|null
     */
    protected static function getIndexFile(FlexStorageInterface $storage)
    {
        // Load saved index file.
        $grav = Grav::instance();
        $locator = $grav['locator'];
        $filename = $locator->findResource('user-data://flex/indexes/sites.yaml', true, true);

        return CompiledYamlFile::instance($filename);
    }
}
