<?php

namespace Grav\Plugin\Reviews;

use Grav\Framework\Flex\Storage\FolderStorage;

class ReviewStorage extends FolderStorage
{
    /**
     * @param string $key
     * @return string
     */
    public function normalizeKey(string $key): string
    {
        return mb_strtolower(trim($key, '/'));
    }
}
