<?php

declare(strict_types=1);

namespace Grav\Plugin\AlgoliaPro;

use Algolia\AlgoliaSearch\Exceptions\MissingObjectId;
use Grav\Common\Grav;
use Grav\Framework\Flex\FlexDirectory;
use Grav\Plugin\Reviews\ReviewCollection;
use Grav\Plugin\Reviews\ReviewObject;

class FlexReviewsSearch extends BaseSearch implements AlgoliaProClassInterface
{
    /**
     * @param string $query
     * @param array $options
     * @return array
     */
    public function searchObjects(string $query, array $options = []): array
    {
        $index = $this->getIndexer($this->getIndexName());
        $index->setSettings($this->index_configuration->get('search_params'));
        return $index->search($query, $options);
    }

    /**
     * @param array $options
     * @return array
     */
    public function indexObjects(array $options = []): array
    {
        if (isset($options['flush'])) {
            $this->clearObjects($options);
        }
        return $this->indexReviews();
    }

    /**
     * @param array $options
     * @return array
     */
    public function clearObjects(array $options = []): array
    {
        $index = $this->getIndexer($this->getIndexName());
        $index->clearObjects();
        return [];
    }

    /**
     * @param object $object
     * @param array $options
     * @return array|string[]
     */
    public function updateObject(object $object, array $options = []): array
    {
        return $this->modifyObject($object, $options, true);
    }

    /**
     * @param object $object
     * @param array $options
     * @return array|string[]
     */
    public function deleteObject(object $object, array $options = []): array
    {
        return $this->modifyObject($object, $options, false);
    }

    /**
     * @param object $object
     * @param array $options
     * @param bool $update
     * @return array|string[]
     */
    public function modifyObject(object $object, array $options = [], bool $update = true): array
    {
        if (Grav::instance()['config']->get('plugins.algolia-pro.production_mode') === false) {
            return ['status' => 'success', 'message' => 'test mode'];
        }
        $status = [];
        if ($object instanceof ReviewObject) {
            $records = $this->getReviewRecord($object);
            $status = $this->updateRecord($records, $object, $update);
        }
        return $status;
    }

    /**
     * @param callable $callback
     * @return void
     */
    public function setProgressCallback(callable $callback): void
    {
        $this->progress_callback = $callback;
    }

    /**
     * @return callable|null
     */
    public function getProgressCallback(): ?callable
    {
        return $this->progress_callback;
    }

    /**
     * @param array $records
     * @param ReviewObject $object
     * @param bool $update
     * @return array|string[]
     */
    protected function updateRecord(array $records, ReviewObject $object, bool $update): array
    {

        if (isset($records[0])) {
            $index = $this->getIndexer($this->getIndexName());
            $objectIDs = $this->getObjectsByDistinct($records[0], $index);
            if (!empty($objectIDs)) {
                $index->deleteObjects($objectIDs);
            }

            if ($update) {
                try {
                    $index->saveObjects($records);
                } catch (MissingObjectId $e) {
                    return ['status' => 'error', 'message' => $e->getMessage()];
                }
            }
            $status = ['status' => 'success'];

        } else {
            $status = ['status' => 'error', 'message' => 'no record found'];
        }
        return $status;
    }

    /**
     * @param string|null $index
     * @return string
     */
    protected function getIndexName(string $index = null): string
    {
        $index_name = $this->plugin_configuration->get('base_index_name');
        if (!is_string($index_name)) {
            $index_name = 'grav';
        }

        return "{$this->name}-{$index_name}";
    }

    /**
     * @return array
     */
    protected function indexReviews(): array
    {
        $grav = Grav::instance();
        $flex = $grav['flex'];
        /** @var FlexDirectory $directory */
        $directory = $flex->getDirectory('reviews');
        /** @var ReviewCollection $collection */
        $collection = $directory->getCollection()->filterBy(['published' => true]);
        $steps = count($collection);
        $index = $this->getIndexer($this->getIndexName());
        $counter = 0;
        $records = [];
        $status = [];

        if ($callback = $this->getProgressCallback()) {
            $callback($steps, 'Index Config: <yellow>' . $this->name . '</yellow> | Algolia Index: <yellow>' . $index->getIndexName() . '</yellow>');
        }

        foreach ($collection as $object) {
            $counter++;
            try {
                $content_records = $this->getReviewRecord($object);
                if (count($content_records) > 0) {
                    $records = array_merge($records, $content_records);
                    $status[] = [
                        'status' => 'success',
                        'msg' => 'Page indexed',
                        'url' => $object->url(),
                    ];
                    if ($callback = $this->getProgressCallback()) {
                        $callback();
                    }
                } else {
                    throw new \Exception("No records found");
                }
            } catch (\Exception $e) {
                $status[] = [
                    'status' => 'error',
                    'msg' => $object->id . ": " . $e->getMessage(),
                    'url' => $object->url(),
                ];
                if ($callback = $this->getProgressCallback()) {
                    $callback(-1);
                }
                continue;
            }
        }

        if ($this->plugin_configuration->get('production_mode') !== false && !empty($records)) {
            $index->partialUpdateObjects($records, [
                'createIfNotExists' => true
            ]);
        }

        return $status;
    }

    /**
     * @param ReviewObject $object
     * @return array
     */
    protected function getReviewRecord(ReviewObject $object): array
    {
        $records = [];
        $record = new \stdClass();
        $counter = 0;

        // Standard bits
        $record->id = $object->getFlexKey();
        $record->title = $object->review_title;
        $record->name = $object->product_name;
        $record->url = $object->url();

        // Store entry for each section
        foreach ($object->sections as $section) {
            $record->header =$section['intro'];
            $content_chunks = $this->splitHTMLContent($section['content']);

            foreach ($content_chunks as $content_chunk) {
                $record->content = $content_chunk['content'];
                $record->objectID = $record->id . '-' . $counter++;
                $records[] = (array) $record;
            }
        }

        // Store entry with good/bad score
        $record->content = "score: {$object->score}\ngood: {$object->good}\nbad: {$object->bad}";
        $record->objectID = $record->id . '-score';
        $records[] = (array) $record;

        return $records;
    }
}
