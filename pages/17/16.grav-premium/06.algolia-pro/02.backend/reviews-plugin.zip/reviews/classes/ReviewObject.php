<?php

namespace Grav\Plugin\Reviews;

use Grav\Common\Flex\Types\Generic\GenericObject;
use Grav\Common\Utils;

class ReviewObject extends GenericObject
{
    public function url(): String
    {
        $route = $this->getProperty('review_route');
        return Utils::url('/reviews/id:' . $route);
    }

    public function save(): ReviewObject
    {
        $route = $this->getProperty('review_route');

        // Make sure that route is unique.
        if (!$route) {
            throw new \RuntimeException('Review route has not been defined!');
        }

        $test = $this->getFlexDirectory()->getObject(trim($route, '/'));
        if ($test && (!$this->exists() || $test->getStorageKey() !== $this->getStorageKey())) {
            $test_name = $test->getProperty('product_name');
            throw new \RuntimeException("<b>Review Route</b> already exists for review: <b>'$test_name'</b>. Please enter a unique value.");
        }

        parent::save();

        return $this;
    }
}
