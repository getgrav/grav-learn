<?php

namespace Grav\Plugin\Reviews;

use Grav\Common\Flex\Types\Generic\GenericCollection;

class ReviewCollection extends GenericCollection
{
}
